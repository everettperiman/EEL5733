make 
./location_updater #buffersize < input.txt